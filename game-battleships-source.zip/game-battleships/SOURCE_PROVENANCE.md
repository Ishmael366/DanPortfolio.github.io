# Imported tutorial source

Repository: https://github.com/kubowania/battleships
Commit: ed4a739219b343f6f6ae1781d5ea36beb58faea7

Matched public author repository and project subject; exact tutorial endpoint unverified:
- Let's build Battleships in JavaScript! — https://www.youtube.com/watch?v=Ubh_k18sX4E

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

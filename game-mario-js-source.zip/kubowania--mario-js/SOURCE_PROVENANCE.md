# Imported tutorial source

Repository: https://github.com/kubowania/mario-js
Commit: 5c055d362cfc1afd7cd76c99eac2f08a296cbcc8

Matched public author repository and project subject; exact tutorial endpoint unverified:
- 2hrs to code Mario with Auth + save scores | JavaScript, CSS, HTML — https://www.youtube.com/watch?v=1CVSI3MZNNg

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

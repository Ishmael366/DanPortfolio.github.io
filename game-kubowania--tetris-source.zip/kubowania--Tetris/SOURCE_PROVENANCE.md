# Imported tutorial source

Repository: https://github.com/kubowania/Tetris
Commit: 76f359b53934a91677341e09a67aacc37eb67c95

Linked directly in these playlist video descriptions:
- Learn JavaScript by Building 7 Games - Full Course — https://www.youtube.com/watch?v=lhNdUVh3qCc

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

# Browser adaptation source map

Reference repository: zigurous--unity-flappy-bird-tutorial

Press Space or click to flap. Fly between the pipes.

Browser implementation: canvas-games.js using mode flappy.

Selected original controller behavior is translated to JavaScript. This is not an exported Unity build or a feature-complete port. Visual geometry, level layout, balancing, scoring, controls, and the browser UI may differ. Rider uses simplified track-contact physics; tower defense uses 5 demonstration waves; ecosystem uses simplified feeding/energy/reproduction and does not claim the unfinished original gene inheritance implementation.

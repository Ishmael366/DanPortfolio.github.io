# Imported tutorial source

Repository: https://github.com/zigurous/unity-flappy-bird-tutorial
Commit: 4ffe9808c100ca1d415989ed2388d8bfa45528a2

Linked directly in these playlist video descriptions:
- How to make Flappy Bird in Unity (Complete Tutorial) — https://www.youtube.com/watch?v=ihvBiJ1oC9U

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

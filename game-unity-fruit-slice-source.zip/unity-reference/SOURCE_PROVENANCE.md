# Imported tutorial source

Repository: https://github.com/Brackeys/Fruit-Ninja-Replica
Commit: 1286682b4d38da8544edd93d929190977439cb47

Linked directly in these playlist video descriptions:
- How to make Fruit Slicing in Unity (Livestream) — https://www.youtube.com/watch?v=3g5_8sE18tQ

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

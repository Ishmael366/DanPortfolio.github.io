# Tutorial provenance

Playlist: Simulations
Position: 7
Title: Pokémon JavaScript Game Tutorial with HTML Canvas
Video: https://www.youtube.com/watch?v=yP5DKzriqXA
Author repository: https://github.com/chriscourses/pokemon-style-game
Pinned commit: a09cce8b0c3826fc2ff879b58566ec03d2ea10e0

Repository link verified in the exact video's description. Original code and attribution retained. This is an imported tutorial project, not a claim of original authorship.

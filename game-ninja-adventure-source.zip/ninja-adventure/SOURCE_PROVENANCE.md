# Tutorial provenance

Playlist: Simulations
Position: 3
Title: Create a Legend of Zelda Style Game with JavaScript
Video: https://www.youtube.com/watch?v=zogxGGDJ2Ok
Author repository: https://github.com/chriscourses/ninja-adventure
Pinned commit: e58744980555523c90a41409af8b12857003bd49

Repository link verified in the exact video's description. Original code and attribution retained. This is an imported tutorial project, not a claim of original authorship.

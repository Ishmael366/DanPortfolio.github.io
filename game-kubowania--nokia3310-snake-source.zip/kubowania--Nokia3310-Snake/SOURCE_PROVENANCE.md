# Imported tutorial source

Repository: https://github.com/kubowania/Nokia3310-Snake
Commit: 3f96f06ed10701fda91344d31ec9c6b1e463c48a

Linked directly in these playlist video descriptions:
- Learn JavaScript by Building 7 Games - Full Course — https://www.youtube.com/watch?v=lhNdUVh3qCc

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

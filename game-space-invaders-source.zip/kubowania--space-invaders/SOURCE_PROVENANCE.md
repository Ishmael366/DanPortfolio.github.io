# Imported tutorial source

Repository: https://github.com/kubowania/space-invaders
Commit: 646db3a8640e893b8381e65986d91ede54632866

Linked directly in these playlist video descriptions:
- Learn JavaScript by Building 7 Games - Full Course — https://www.youtube.com/watch?v=lhNdUVh3qCc
- Learn JavaScript by Building 7 Games - Full Course — https://www.youtube.com/watch?v=ec8vSKJuZTk

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

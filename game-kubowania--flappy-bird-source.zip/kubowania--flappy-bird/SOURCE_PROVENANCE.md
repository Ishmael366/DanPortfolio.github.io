# Imported tutorial source

Repository: https://github.com/kubowania/flappy-bird
Commit: 0f7c8523ce88ed206c5cd766c6814dad244082a3

Linked directly in these playlist video descriptions:
- JavaScript Tutorial: Build Flappy Bird and Doodle Jump — https://www.youtube.com/watch?v=8xPsg6yv7TU

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

# Imported tutorial source

Repository: https://github.com/kubowania/breakout
Commit: 82df3662a709f3aad4aa5b2d81d083617c0efc1b

Linked directly in these playlist video descriptions:
- Learn JavaScript by Building 7 Games - Full Course — https://www.youtube.com/watch?v=ec8vSKJuZTk

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

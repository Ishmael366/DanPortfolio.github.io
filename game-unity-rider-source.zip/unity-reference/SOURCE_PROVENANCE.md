# Imported tutorial source

Repository: https://github.com/Brackeys/Rider-Replica
Commit: 4f14214de87d2c6aa09356ec65fdad88c6416377

Linked directly in these playlist video descriptions:
- How to make RIDER in Unity (Livestream) — https://www.youtube.com/watch?v=9Ztd1XXmUGI

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

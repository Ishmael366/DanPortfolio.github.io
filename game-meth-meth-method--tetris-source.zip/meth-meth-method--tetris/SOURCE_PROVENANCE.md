# Imported tutorial source

Repository: https://github.com/meth-meth-method/tetris
Commit: c3c7fbcd8ecaebec8c97feb265aa58ce481d04d1

Linked directly in these playlist video descriptions:
- Tetris game in JavaScript / Canvas — tutorial — https://www.youtube.com/watch?v=H2aW5V46khA

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

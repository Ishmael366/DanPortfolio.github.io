# Imported tutorial source

Repository: https://github.com/rutura/The-C-20-Masterclass-Source-Code
Commit: 1875e9beddd790270396c59166d5bde9bdec6fc6

Linked directly in these playlist video descriptions:
- C++ Programming Course - Beginner to Advanced — https://www.youtube.com/watch?v=8jLOx1hD3_o

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

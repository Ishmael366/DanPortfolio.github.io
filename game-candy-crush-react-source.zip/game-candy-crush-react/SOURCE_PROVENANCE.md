# Imported tutorial source

Repository: https://github.com/kubowania/candy-crush-reactjs
Commit: 9fffcbeb4ea830d8ad90c1edfcf19c6492680779

Linked directly in these playlist video descriptions:
- Candy Crush in React — https://www.youtube.com/watch?v=PBrEq9Wd6_U

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

# Source provenance

Playlist: Simulations / position 12
Tutorial: Space Invaders Game Tutorial with JavaScript and HTML Canvas
Video: https://www.youtube.com/watch?v=MCVU0w73uKI
Author repository: https://github.com/chriscourses/space-invaders
Commit: dc011b2d665b15a9854e6c9457fd4218e98efe13

Matched by tutorial author and game subject. The video description does not link this repository directly; exact lesson endpoint is not confirmed. Preserve upstream credit.

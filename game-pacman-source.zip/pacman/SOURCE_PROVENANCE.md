# Source provenance

Playlist: Simulations / position 10
Tutorial: Pacman Game Tutorial with JavaScript and HTML5 Canvas
Video: https://www.youtube.com/watch?v=5IMXpp3rohQ
Author repository: https://github.com/chriscourses/pacman
Commit: 429a68501619b6a739b082fca3c174a7593a85f6

Matched by tutorial author and game subject. The video description does not link this repository directly; exact lesson endpoint is not confirmed. Preserve upstream credit.

# Imported tutorial source

Repository: https://github.com/MaxRobinsonTheGreat/EvolutionSimulator
Commit: 207ae06d5eefaf333d5d8ceee614ed82aec6958e

Linked directly in these playlist video descriptions:
- Evolution Simulator [The Life Engine] — https://www.youtube.com/watch?v=4XEklaH9k6k

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

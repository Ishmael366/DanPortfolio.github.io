# Imported tutorial source

Repository: https://github.com/SebLague/Ecosystem-2
Commit: 5763e0f6a4495d5b15a1c24083c9672dd5b3acd3

Linked directly in these playlist video descriptions:
- Coding Adventure: Simulating an Ecosystem — https://www.youtube.com/watch?v=r_It_X7v-1E

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

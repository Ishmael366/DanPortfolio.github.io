# Tutorial provenance

Playlist: Simulations
Position: 2
Title: ASMR Pong Programming in the Park
Video: https://www.youtube.com/watch?v=gCe_CNyPk5k
Author repository: https://github.com/chriscourses/programming-pong-in-the-park
Pinned commit: 503d706de3cce670921df186b96e80689e75e33c

Repository link verified in the exact video's description. Original code and attribution retained. This is an imported tutorial project, not a claim of original authorship.

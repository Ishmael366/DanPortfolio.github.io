# Imported tutorial source

Repository: https://github.com/weibenfalk/react-tetris-starter-files
Commit: d735709500ce99a0ca641260620c0b2f3255af9a

Linked directly in these playlist video descriptions:
- How to Build Tetris in React — https://www.youtube.com/watch?v=ZGOaCxX8HIU

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

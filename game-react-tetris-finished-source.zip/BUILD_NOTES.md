Original FINISHED tutorial solution from weibenfalk/react-tetris-starter-files. React 16.8.6 / styled-components 4.3.2. Original notices retained.

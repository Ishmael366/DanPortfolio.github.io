# Source provenance

Playlist: Simulations / position 9
Tutorial: Mario Game Tutorial with JavaScript and HTML Canvas
Video: https://www.youtube.com/watch?v=4q2vvZn5aoo
Author repository: https://github.com/chriscourses/mario-game
Commit: cf452b2a295a5f8b226e7847c60dc1179b68a31b

Matched by tutorial author and game subject. The video description does not link this repository directly; exact lesson endpoint is not confirmed. Preserve upstream credit.

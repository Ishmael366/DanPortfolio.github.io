# Imported tutorial source

Repository: https://github.com/kubowania/whac-a-mole
Commit: d25ce31c87ab81011f865e684bad0f15c8a81270

Linked directly in these playlist video descriptions:
- Learn JavaScript by Building 7 Games - Full Course — https://www.youtube.com/watch?v=ec8vSKJuZTk

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

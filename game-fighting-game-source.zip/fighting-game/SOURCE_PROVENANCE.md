# Tutorial provenance

Playlist: Simulations
Position: 11
Title: JavaScript Fighting Game Tutorial with HTML Canvas
Video: https://www.youtube.com/watch?v=vyqbNFMDRGQ
Author repository: https://github.com/chriscourses/fighting-game
Pinned commit: e39c1c59ac5b133468da25ee2251f8062416ebdc

Repository link verified in the exact video's description. Original code and attribution retained. This is an imported tutorial project, not a claim of original authorship.

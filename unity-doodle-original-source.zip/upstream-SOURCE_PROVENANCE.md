# Imported tutorial source

Repository: https://github.com/Brackeys/Doodle-Jump-Replica
Commit: 07585fe4b2e41d32499fcec938a1b034953b03d9

Linked directly in these playlist video descriptions:
- How to make Doodle Jump in Unity (Livestream) — https://www.youtube.com/watch?v=fHN-26GEVhA

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

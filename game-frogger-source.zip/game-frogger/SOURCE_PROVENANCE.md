# Imported tutorial source

Repository: https://github.com/kubowania/Frogger
Commit: 3c72a07db9b785f99dd4f5cc77589c699a5a79c3

Linked directly in these playlist video descriptions:
- Learn JavaScript by Building 7 Games - Full Course — https://www.youtube.com/watch?v=lhNdUVh3qCc
- Learn JavaScript by Building 7 Games - Full Course — https://www.youtube.com/watch?v=ec8vSKJuZTk

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

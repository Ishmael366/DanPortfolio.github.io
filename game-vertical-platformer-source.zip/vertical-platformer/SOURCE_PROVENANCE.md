# Tutorial provenance

Playlist: Simulations
Position: 8
Title: Vertical Platformer Game Tutorial with JavaScript and HTML Canvas
Video: https://www.youtube.com/watch?v=rTVoyWu8r6g
Author repository: https://github.com/chriscourses/vertical-platformer
Pinned commit: fa3d460de134ae395eab4b2c5100fdb4a96a5bca

Repository link verified in the exact video's description. Original code and attribution retained. This is an imported tutorial project, not a claim of original authorship.

# Tutorial provenance

Playlist: Simulations
Position: 13
Title: Tower Defense Game Tutorial with JavaScript & HTML Canvas
Video: https://www.youtube.com/watch?v=C4_iRLlPNFc
Author repository: https://github.com/chriscourses/tower-defense
Pinned commit: 74807e0e21298ecda8de4cdd6598962535a34d1f

Repository link verified in the exact video's description. Original code and attribution retained. This is an imported tutorial project, not a claim of original authorship.

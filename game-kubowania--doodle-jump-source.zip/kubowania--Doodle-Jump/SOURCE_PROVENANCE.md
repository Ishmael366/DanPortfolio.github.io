# Imported tutorial source

Repository: https://github.com/kubowania/Doodle-Jump
Commit: caa860657407975354ca23cd4a48c7fda4031c92

Linked directly in these playlist video descriptions:
- Doodle Jump in JavaScript — https://www.youtube.com/watch?v=YSEsSs3hB6A
- JavaScript Tutorial: Build Flappy Bird and Doodle Jump — https://www.youtube.com/watch?v=8xPsg6yv7TU

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

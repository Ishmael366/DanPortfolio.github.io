# Tutorial provenance

Playlist: Simulations
Position: 5
Title: Three.js 3D Game Tutorial: In-Depth Course for All Levels
Video: https://www.youtube.com/watch?v=sPereCgQnWQ
Author repository: https://github.com/chriscourses/threejs-game
Pinned commit: 2cbffa10d405617e95e90da703ad543d74302951

Repository link verified in the exact video's description. Original code and attribution retained. This is an imported tutorial project, not a claim of original authorship.

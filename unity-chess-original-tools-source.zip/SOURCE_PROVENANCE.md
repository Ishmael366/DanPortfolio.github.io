Upstream: https://github.com/andrewnakas/2dUnityChess
Commit: ea142768298d24767c2764979cf9d620171f9a86
Saved tutorial video ID: qVhG6ZWqD-o
Code license: MIT; original notices retained. Prepared for a browser build, not yet verified or published.

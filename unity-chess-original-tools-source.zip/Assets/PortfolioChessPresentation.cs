using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

// Original procedural presentation. MIT tutorial-derived game rules remain in ChessBoard.
public sealed class PortfolioChessPresentation : MonoBehaviour {
    readonly HashSet<ChessPiece> presented = new HashSet<ChessPiece>();
    Material ivory, obsidian, lightTile, darkTile, moveTile, lastTile;
    ChessBoard board; Camera view; string keyboardMove = "", message = "Two players · drag a piece, or type e2e4 and press Enter";
    bool top; float angle;
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)] static void Init() {
        GraphicsSettings.renderPipelineAsset = null; QualitySettings.renderPipeline = null;
        SceneManager.sceneLoaded += (s,m) => new GameObject("Portfolio Chess Presentation").AddComponent<PortfolioChessPresentation>();
    }
    Material Mat(Color color, float metallic = 0f) {
        var m = new Material(Resources.Load<Material>("PortfolioStandard").shader); m.color = color; m.SetFloat("_Metallic",metallic); m.SetFloat("_Glossiness", .65f); return m;
    }
    void Start() {
        board = FindObjectOfType<ChessBoard>(); view = Camera.main;
        ivory=Mat(new Color(.92f,.86f,.70f),.2f); obsidian=Mat(new Color(.10f,.15f,.20f),.55f);
        lightTile=Mat(new Color(.73f,.77f,.73f));darkTile=Mat(new Color(.14f,.24f,.28f));moveTile=Mat(new Color(.31f,.62f,.49f));lastTile=Mat(new Color(.74f,.57f,.24f));
        RenderSettings.ambientLight=new Color(.40f,.45f,.51f);RenderSettings.ambientMode=AmbientMode.Flat;
        var lamp=new GameObject("Chess key light").AddComponent<Light>();lamp.type=LightType.Directional;lamp.intensity=1.5f;lamp.shadows=LightShadows.Soft;lamp.transform.rotation=Quaternion.Euler(30,35,0);
        foreach(var c in FindObjectsOfType<CameraTrackingScript>())c.enabled=false;
        foreach(var a in FindObjectsOfType<AiManager>()) {
            a.isWhiteStockfish=a.isBlackStockfish=false;
            if(a.whiteDropDown){a.whiteDropDown.value=0;a.whiteDropDown.interactable=false;}
            if(a.blackDropDown){a.blackDropDown.value=0;a.blackDropDown.interactable=false;}
        }
        foreach(var c in FindObjectsOfType<huggingFaceStock>())c.enabled=false;
        if(board && board.evalSlider)board.evalSlider.gameObject.SetActive(false);
        Box("Walnut board",transform,new Vector3(4,4,.22f),new Vector3(8.45f,8.45f,.35f),Mat(new Color(.16f,.11f,.08f)));
        if(view){view.orthographic=false;view.fieldOfView=47;view.backgroundColor=new Color(.035f,.06f,.09f);view.clearFlags=CameraClearFlags.SolidColor;}
    }
    void Update() {
        foreach(char c in Input.inputString) {
            char k=char.ToLowerInvariant(c);
            if(k=='\b' && keyboardMove.Length>0)keyboardMove=keyboardMove.Substring(0,keyboardMove.Length-1);
            else if(k=='\n'||k=='\r'){if(board){message=board.PortfolioMove(keyboardMove);keyboardMove="";}}
            else if((k>='a'&&k<='h')||(k>='1'&&k<='8')){if(keyboardMove.Length>=4)keyboardMove="";keyboardMove+=k;}
        }
        if(Input.GetKey(KeyCode.LeftArrow))angle-=35*Time.deltaTime;
        if(Input.GetKey(KeyCode.RightArrow))angle+=35*Time.deltaTime;
    }
    void LateUpdate() {
        if(view){var center=new Vector3(4,4,0);var offset=top?new Vector3(0,0,-11.5f):Quaternion.AngleAxis(angle,Vector3.forward)*new Vector3(0,-7.8f,-10.6f);view.transform.position=center+offset;view.transform.LookAt(center,Vector3.up);}
        if(!board)return;
        if(Time.frameCount%10==0)foreach(var piece in FindObjectsOfType<ChessPiece>())if(presented.Add(piece))Present(piece);
        if(board.tiles!=null)foreach(var tile in board.tiles)if(tile){var n=LayerMask.LayerToName(tile.layer);var r=tile.GetComponent<MeshRenderer>();if(r){var x=Mathf.FloorToInt(tile.GetComponent<MeshFilter>().sharedMesh.bounds.center.x);var y=Mathf.FloorToInt(tile.GetComponent<MeshFilter>().sharedMesh.bounds.center.y);r.sharedMaterial=n=="Highlight"?moveTile:(n=="LastMoveStart"||n=="LastMoveFinshed")?lastTile:(x+y)%2==0?lightTile:darkTile;}}
    }
    void OnGUI() {
        GUI.backgroundColor=new Color(.07f,.14f,.20f);GUI.color=Color.white;
        if(GUI.Button(new Rect(14,14,100,32),top?"3D view":"Top view"))top=!top;
        if(GUI.Button(new Rect(120,14,90,32),"Flip view"))angle+=180;
        GUI.Box(new Rect(14,Screen.height-58,Mathf.Min(Screen.width-28,670),44),message+"\n"+(keyboardMove.Length>0?"Move: "+keyboardMove:"Left / right arrows rotate the view"));
    }
    void Present(ChessPiece piece) {
        foreach(var s in piece.GetComponentsInChildren<SpriteRenderer>())s.enabled=false;
        var root=new GameObject("Procedural chess piece").transform;root.SetParent(piece.transform,false);root.localRotation=Quaternion.Euler(-90,0,0);root.localScale=Vector3.one*5;
        var mat=piece.team==0?ivory:obsidian;
        var profile=new List<Vector2>{new Vector2(.38f,0),new Vector2(.43f,.06f),new Vector2(.42f,.13f),new Vector2(.31f,.19f),new Vector2(.29f,.25f),new Vector2(.17f,.32f)};
        float neck=piece.type==ChessPieceType.Pawn?.53f:.85f;profile.Add(new Vector2(.12f,neck-.10f));profile.Add(new Vector2(.22f,neck));profile.Add(new Vector2(.22f,neck+.06f));Lathe(root,profile,mat);
        if(piece.type==ChessPieceType.Pawn)Sphere(root,new Vector3(0,.74f,0),.19f,mat);
        else if(piece.type==ChessPieceType.Rook){Box("Crown",root,new Vector3(0,1.02f,0),new Vector3(.55f,.16f,.55f),mat);for(int i=0;i<4;i++){float a=i*Mathf.PI/2;Box("Battlement",root,new Vector3(Mathf.Cos(a)*.19f,1.15f,Mathf.Sin(a)*.19f),new Vector3(.15f,.20f,.15f),mat);}}
        else if(piece.type==ChessPieceType.Knight){Box("Neck",root,new Vector3(0,1.0f,0),new Vector3(.28f,.55f,.25f),mat);var head=Box("Horse head",root,new Vector3(.11f,1.28f,0),new Vector3(.48f,.27f,.25f),mat);head.localRotation=Quaternion.Euler(0,0,-17);Box("Ear",root,new Vector3(-.08f,1.49f,0),new Vector3(.12f,.24f,.14f),mat);}
        else if(piece.type==ChessPieceType.Bishop){Sphere(root,new Vector3(0,1.13f,0),.24f,mat);Sphere(root,new Vector3(0,1.38f,0),.06f,mat);}
        else {Sphere(root,new Vector3(0,1.10f,0),.23f,mat);if(piece.type==ChessPieceType.King){Box("Cross upright",root,new Vector3(0,1.44f,0),new Vector3(.11f,.45f,.11f),mat);Box("Cross arms",root,new Vector3(0,1.48f,0),new Vector3(.35f,.11f,.11f),mat);}else for(int i=0;i<6;i++){float a=i*Mathf.PI/3;Sphere(root,new Vector3(Mathf.Cos(a)*.19f,1.35f,Mathf.Sin(a)*.19f),.07f,mat);}}
    }
    Transform Box(string name,Transform parent,Vector3 position,Vector3 scale,Material mat){var g=GameObject.CreatePrimitive(PrimitiveType.Cube);g.name=name;g.transform.SetParent(parent,false);g.transform.localPosition=position;g.transform.localScale=scale;g.GetComponent<Renderer>().sharedMaterial=mat;Destroy(g.GetComponent<Collider>());return g.transform;}
    void Sphere(Transform parent,Vector3 position,float radius,Material mat){var g=GameObject.CreatePrimitive(PrimitiveType.Sphere);g.transform.SetParent(parent,false);g.transform.localPosition=position;g.transform.localScale=Vector3.one*radius*2;g.GetComponent<Renderer>().sharedMaterial=mat;Destroy(g.GetComponent<Collider>());}
    void Lathe(Transform parent,List<Vector2> profile,Material mat){const int sides=32;var vertices=new Vector3[profile.Count*sides];var triangles=new int[(profile.Count-1)*sides*6];for(int j=0;j<profile.Count;j++)for(int i=0;i<sides;i++){float a=i*2*Mathf.PI/sides;vertices[j*sides+i]=new Vector3(Mathf.Cos(a)*profile[j].x,profile[j].y,Mathf.Sin(a)*profile[j].x);if(j==profile.Count-1)continue;int k=(j*sides+i)*6,n=(i+1)%sides;triangles[k]=j*sides+i;triangles[k+1]=(j+1)*sides+i;triangles[k+2]=(j+1)*sides+n;triangles[k+3]=j*sides+i;triangles[k+4]=(j+1)*sides+n;triangles[k+5]=j*sides+n;}var mesh=new Mesh();mesh.vertices=vertices;mesh.triangles=triangles;mesh.RecalculateNormals();var g=new GameObject("Turned chess body",typeof(MeshFilter),typeof(MeshRenderer));g.transform.SetParent(parent,false);g.GetComponent<MeshFilter>().sharedMesh=mesh;g.GetComponent<MeshRenderer>().sharedMaterial=mat;}
}

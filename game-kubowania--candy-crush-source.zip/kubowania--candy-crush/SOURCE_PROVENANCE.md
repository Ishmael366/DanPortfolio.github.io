# Imported tutorial source

Repository: https://github.com/kubowania/candy-crush
Commit: 61c052ed4dffd156c2853b35f53d6377028de15d

Linked directly in these playlist video descriptions:
- Make Your Own Candy Crush Game in JavaScript — https://www.youtube.com/watch?v=XD5sZWxwJUk

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

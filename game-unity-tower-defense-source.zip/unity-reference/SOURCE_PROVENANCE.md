# Imported tutorial source

Repository: https://github.com/Brackeys/Tower-Defense-Tutorial
Commit: 166b442b516ca5f2dd09838b355ba0c96438f598

Matched public author repository and project subject; exact tutorial endpoint unverified:
- How to make a Tower Defense Game (E01) - Unity Tutorial — https://www.youtube.com/watch?v=beuoNuK2tbk

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

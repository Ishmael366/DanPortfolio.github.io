# Browser adaptation source map

Reference repository: Brackeys--Tower-Defense-Tutorial

Click a platform to build a $100 turret. Click a built turret to upgrade for $100. Defend 5 waves.

Browser implementation: three-games.js using mode tower.

Selected original controller behavior is translated to JavaScript. This is not an exported Unity build or a feature-complete port. Visual geometry, level layout, balancing, scoring, controls, and the browser UI may differ. Rider uses simplified track-contact physics; tower defense uses 5 demonstration waves; ecosystem uses simplified feeding/energy/reproduction and does not claim the unfinished original gene inheritance implementation.

# Imported tutorial source

Repository: https://github.com/weibenfalk/vanilla-js-pacman
Commit: f4b371e69bce74e82a8f22e6690b0fa1f1b5b616

Linked directly in these playlist video descriptions:
- Build a Pac-Man Game in JavaScript — https://www.youtube.com/watch?v=YBtzzVwrTeE

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

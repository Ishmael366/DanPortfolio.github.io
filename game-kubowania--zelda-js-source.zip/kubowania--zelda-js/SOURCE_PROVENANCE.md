# Imported tutorial source

Repository: https://github.com/kubowania/zelda-js
Commit: a1827ec58c61e39c85cb871843a79064fee68690

Matched public author repository and project subject; exact tutorial endpoint unverified:
- 🎮 Easy JavaScript Game Development with Kaboom.js (Mario, Zelda, and Space Invaders) - Full Course — https://www.youtube.com/watch?v=4OaHB0JbJDI

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

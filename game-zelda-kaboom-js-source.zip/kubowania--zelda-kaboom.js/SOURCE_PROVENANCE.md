# Imported tutorial source

Repository: https://github.com/kubowania/zelda-kaboom.js
Commit: 0f856088b63affb400736a8fc2e133407eb76ce2

Matched public author repository and project subject; exact tutorial endpoint unverified:
- Make a Zelda Game with Kaboom.js — https://www.youtube.com/watch?v=XX93O4ZVUZI

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

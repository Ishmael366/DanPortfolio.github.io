# Local development — in progress

Original stack retained: React 17 / Create React App, Express, Mongoose/MongoDB, JWT, Material UI, Sass, Firebase Storage.

Install dependencies in api, client and admin. Start api with `node local.cjs`; this downloads and starts a real local MongoDB process with a persistent data directory. Start the client and admin with their original start scripts (ports 3000 and 3001). Start Firebase Storage with `firebase emulators:start --only storage --project demo-portfolio-netflix` from this directory.

The Firebase rules are intentionally permissive for the localhost emulator only. Do not deploy these rules to a hosted Firebase project. Local account credentials and database state are excluded from Git.

Current status: API/client dependencies installed; admin installation, emulator launch, seeded catalog, integration repairs and end-to-end validation remain. This project is not yet complete.

Tutorial reference: https://www.youtube.com/watch?v=tsNswx0nRKM
Original code: https://github.com/safak/youtube/tree/mern-netflix-app
Author: Lama Dev / Safak
Reference commit: fa0754adc563f92a9d1acd531f26072629c9f427
This is a tutorial-derived implementation in progress, not original authorship of the reference code.

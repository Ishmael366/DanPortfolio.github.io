const express = require("express");
const app = express();
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const authRoute = require("./routes/auth");
const userRoute = require("./routes/users");
const movieRoute = require("./routes/movies");
const listRoute = require("./routes/lists");

dotenv.config();

mongoose
  .connect(process.env.MONGO_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
  })
  .then(async () => {console.log("DB Connection Successfull"); if(process.env.LOCAL_DEMO === "true") await require("./seed-local.cjs")();})
  .catch((err) => {
    console.error(err);
  });

app.use(express.json());
app.get('/api/demo-cover/:id',(req,res)=>{const colors=['#486b83','#368685','#a36d4c','#65577e','#5f7452','#8c654e'];const i=Math.abs(parseInt(req.params.id)||0)%6;res.type('svg').send(`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="675"><defs><linearGradient id="g"><stop stop-color="${colors[i]}"/><stop offset="1" stop-color="#080c14"/></linearGradient></defs><rect width="1200" height="675" fill="url(#g)"/><circle cx="850" cy="220" r="130" fill="white" opacity=".08"/><path d="M0 675L400 260 800 675 1000 360 1200 675" fill="#060a12" opacity=".5"/><text x="50" y="600" fill="white" font-size="32">LOCAL DEMO COLLECTION</text></svg>`)});
app.get('/api/demo-title/:id',(req,res)=>{const titles=['Beyond the Horizon','Ocean Stories','Orbit One','The Hidden Kingdom','City Lights','Wild Earth'];res.type('svg').send(`<svg xmlns="http://www.w3.org/2000/svg" width="600" height="100"><text x="0" y="70" fill="white" font-size="45">${titles[Math.abs(parseInt(req.params.id)||0)%6]}</text></svg>`)});

app.get("/api/health",(req,res)=>res.json({ok:mongoose.connection.readyState===1}));

app.use("/api/auth", authRoute);
app.use("/api/users", userRoute);
app.use("/api/movies", movieRoute);
app.use("/api/lists", listRoute);

app.listen(8800, "127.0.0.1", () => {
  console.log("Backend server is running!");
});

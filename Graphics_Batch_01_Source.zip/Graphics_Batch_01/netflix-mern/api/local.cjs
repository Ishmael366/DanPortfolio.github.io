const { MongoMemoryServer } = require('mongodb-memory-server');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
(async () => {
 const dir = path.join(__dirname, '.local'); fs.mkdirSync(dir,{recursive:true});
 const secretFile = path.join(dir,'jwt-secret');
 if (!fs.existsSync(secretFile)) fs.writeFileSync(secretFile,crypto.randomBytes(48).toString('hex'),{mode:0o600});
 const mongo = await MongoMemoryServer.create({instance:{dbPath:dir,dbName:'portfolio_netflix',storageEngine:'wiredTiger'}});
 process.env.MONGO_URL = mongo.getUri();
 process.env.SECRET_KEY = fs.readFileSync(secretFile,'utf8');
 process.env.LOCAL_DEMO='true';
 require('./index');
 const stop = async () => { await mongo.stop(); process.exit(0); };
 process.on('SIGINT',stop); process.on('SIGTERM',stop);
})().catch(e=>{console.error(e);process.exit(1)});

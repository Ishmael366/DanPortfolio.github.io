const Movie=require('./models/Movie');const List=require('./models/List');
module.exports=async()=>{
 const ids=[];
 for(const [i,title] of ['Beyond the Horizon','Ocean Stories','Orbit One','The Hidden Kingdom','City Lights','Wild Earth'].entries()){
 const movie=await Movie.findOneAndUpdate({title},{title,desc:'Local fictional sample catalog entry for this independent tutorial project. Upload your own licensed video through the admin to enable playback.',img:'/api/demo-cover/'+i,imgSm:'/api/demo-cover/'+i,imgTitle:'/api/demo-title/'+i,video:'',trailer:'',year:'2026',limit:0,genre:i%2?'documentary':'adventure',isSeries:false},{upsert:true,new:true});ids.push(String(movie._id));
 }
 await List.findOneAndUpdate({title:'Local collection'},{title:'Local collection',type:'movie',genre:'adventure',content:ids},{upsert:true});
 console.log('Local sample catalog ready');
};

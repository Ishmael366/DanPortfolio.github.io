# Graphics — Batch 1 presentations

Three working local visual presentations, ready to show without external accounts.

- Netflix: http://localhost:3101 — cinematic hero, title shelves, search, details, saved list and short preview.
- Disney+: http://localhost:3103/local — branded carousel and tiles, title details, search and saved watchlist.
- Spotify: http://localhost:3104 — music dashboard, collections, search, saved tracks and local audio player.

## Reopen locally
Install Node.js and pnpm. Run pnpm install in netflix-mern/api, netflix-mern/client, disney-nextjs and spotify-nextjs. Build both Next.js projects with pnpm build. Then run node start-local.mjs from this folder. It starts all previews on localhost. Stop with Ctrl+C. Netflix uses the original CRA toolchain with the compatibility settings supplied by the launcher. Local environment examples are included; private environment files are excluded from the archive.

## Presentation scope
Visual interfaces use local sample content. Netflix has fictional titles and local landscape artwork; Disney uses tutorial reference artwork. Video buttons play short brand animations, not full films. Spotify plays original generated sample tones. Saved lists persist in the browser. External account and streaming integrations remain separate future work; these are presentation builds, not full service replicas.

## Validation
All three production builds passed. Browser visual checks completed, including Netflix and Disney saved-list actions and Spotify playback. Earlier Netflix API checks covered registration, login, catalog access and invalid credentials. Firebase emulators and external service flows have not been validated.

## Source attribution
See each project’s SOURCE.md. Netflix and Spotify derive from tutorial repositories. Disney uses a matching-stack reference because the original linked repository was inaccessible; exact lineage remains unverified. Preserve upstream attribution. No public deployment or portfolio changes were made for this batch.

module.exports = {
  experimental: { cpus: 2 },
  images: {
    domains: ["rb.gy"],
  },
};

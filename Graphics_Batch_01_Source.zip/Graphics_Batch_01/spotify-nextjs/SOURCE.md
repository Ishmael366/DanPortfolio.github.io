Original tutorial: https://www.youtube.com/watch?v=5qwpAn8bqCg
Author: Ali Codes
Source linked directly in tutorial description: https://github.com/lukef7fywmrp/spotify-redesign-yt
Original source retained, local setup adaptations documented separately. Next version pinned to React 17 compatible Next 12 rather than drifting latest.

import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const base=fileURLToPath(new URL('.',import.meta.url));
const jobs=[['netflix-mern/api',['local.cjs']],['netflix-mern/client',['node_modules/react-scripts/bin/react-scripts.js','start']],['disney-nextjs',['node_modules/next/dist/bin/next','start','-H','127.0.0.1','-p','3103']],['spotify-nextjs',['node_modules/next/dist/bin/next','start','-H','127.0.0.1','-p','3104']]];
const children=jobs.map(([dir,args])=>spawn(process.execPath,args,{cwd:base+dir,stdio:'inherit',env:{...process.env,BROWSER:'none',NODE_OPTIONS:dir.includes('/client')?'--openssl-legacy-provider':'',DISABLE_ESLINT_PLUGIN:'true',HOST:'127.0.0.1'}}));
const stop=()=>children.forEach(c=>c.kill('SIGTERM'));process.on('SIGINT',stop);process.on('SIGTERM',stop);

from pathlib import Path
import shutil,json,subprocess,concurrent.futures
batch=Path(__file__).resolve().parent; stage=batch/'.pages-build'; dest=batch/'static-output'
node=shutil.which('node')
if not node: raise RuntimeError('Install Node.js before building')
def build(name,source):
 p=stage/name;p.mkdir(parents=True,exist_ok=True);(p/'pages').mkdir(exist_ok=True);(p/'styles').mkdir(exist_ok=True)
 base='/DanPortfolio.github.io/demos/'+name
 src=batch/source
 deps=batch/('spotify-nextjs' if name=='spotify' else 'disney-nextjs')/'node_modules'
 if not (p/'node_modules').exists():(p/'node_modules').symlink_to(deps,target_is_directory=True)
 (p/'package.json').write_text(json.dumps({'name':name+'-presentation','private':True,'scripts':{'build':'next build && next export'},'dependencies':{'next':'12.3.7','react':'17.0.2','react-dom':'17.0.2'}}))
 (p/'next.config.js').write_text('module.exports='+json.dumps({'basePath':base,'trailingSlash':True,'experimental':{'cpus':2}}))
 if name=='netflix':
  js=(src/'src/Presentation.jsx').read_text().replace("import './presentation.css';",'').replace('/presentation/',base+'/presentation/').replace('href="/presentation"','href="'+base+'/"').replace('<a href="/login">Open tutorial account flow</a>','<a href="/DanPortfolio.github.io/entertainment.html">Back to portfolio</a>')
  css=(src/'src/presentation.css').read_text(); public=src/'public'
 else:
  js=(src/'pages/local.js').read_text();css=(src/'styles/presentation.css').read_text();public=src/'public'
  for folder in ['images','videos','demo']:js=js.replace('/'+folder+'/',base+'/'+folder+'/');css=css.replace('/'+folder+'/',base+'/'+folder+'/')
  js=js.replace('href="/local"','href="'+base+'/"')
 (p/'pages/index.js').write_text(js)
 (p/'styles/presentation.css').write_text('html,body{margin:0;padding:0;font-family:Arial,sans-serif}*{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}\n'+css)
 app='import "../styles/presentation.css";\n'
 if name=='spotify':app+='import {RecoilRoot} from "recoil";export default function App({Component,pageProps}){return <RecoilRoot><Component {...pageProps}/></RecoilRoot>}'
 else:app+='export default function App({Component,pageProps}){return <Component {...pageProps}/>}'
 (p/'pages/_app.js').write_text(app)
 shutil.copytree(public,p/'public',dirs_exist_ok=True)
 with (p/'build.log').open('w') as log:
  for args in [['build'],['export']]:subprocess.run([node,str(deps/'next/dist/bin/next'),*args],cwd=p,stdout=log,stderr=log,check=True)
 shutil.copytree(p/'out',dest/name,dirs_exist_ok=True)
 print(name+' exported',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(lambda x:build(*x),[('netflix','netflix-mern/client'),('disney','disney-nextjs'),('spotify','spotify-nextjs')]))

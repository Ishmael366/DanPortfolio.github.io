import firebase from "firebase/app";
import "firebase/firestore";
const app = firebase.apps.length ? firebase.app() : firebase.initializeApp({apiKey:process.env.FIREBASE_API_KEY || "demo-local",projectId:process.env.FIREBASE_PROJECT_ID || "demo-portfolio-disney",appId:"demo-local"});
const db=app.firestore();
if (!process.env.FIREBASE_PROJECT_ID && typeof window === "undefined") db.settings({host:"127.0.0.1:8080",ssl:false});
export {db};

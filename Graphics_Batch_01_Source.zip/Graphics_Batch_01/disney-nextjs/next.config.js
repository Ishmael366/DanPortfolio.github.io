/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: { cpus: 2 },
  images: {
    domains: ['https://lh3.googleusercontent.com', 'image.tmdb.org'],
  },
}

module.exports = nextConfig

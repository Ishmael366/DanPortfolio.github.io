# Imported tutorial source

Repository: https://github.com/0shuvo0/squidgame
Commit: 3da9b1351498a1c2252200caab3d632d8f1b380d

Linked directly in these playlist video descriptions:
- Code a Squid Game JavaScript Game Using Three.js - Tutorial for Beginners — https://www.youtube.com/watch?v=4HSxX-EKJjw

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

# Imported tutorial source

Repository: https://github.com/kubowania/connect-four
Commit: 8d6c611add3b080acf83189dc02c810b37dab393

Linked directly in these playlist video descriptions:
- Learn JavaScript by Building 7 Games - Full Course — https://www.youtube.com/watch?v=lhNdUVh3qCc
- Learn JavaScript by Building 7 Games - Full Course — https://www.youtube.com/watch?v=ec8vSKJuZTk
- Connect Four in JavaScript — https://www.youtube.com/watch?v=aroYjgQH8Tw

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

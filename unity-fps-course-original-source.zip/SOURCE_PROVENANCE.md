Upstream: https://github.com/fabio98p/Unity_FPS_3D
Commit: 10d737e9c25d58956483cac6f8d385696718ad2a
Saved tutorial video ID: rJqP5EesxLk
Code license: MIT; original notices retained. Prepared for a browser build, not yet verified or published.

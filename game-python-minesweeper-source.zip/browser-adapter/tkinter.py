# Browser DOM adapter for the Tkinter subset used by the original tutorial.
from js import document
from pyodide.ffi import create_proxy
__all__=['Tk','Frame','Label','Button']
_callbacks=[]
def color(v):return {'SystemButtonFace':'#263c54','black':'#101c2b','white':'#f3f7fc','red':'#ef5267','orange':'#f6ad55'}.get(v,v)
class Widget:
    tag='div'
    def __init__(self,parent=None,**kw):
        self.node=document.createElement(self.tag);self.bindings={};self.node.className='tk-'+self.__class__.__name__.lower();self.parent=parent
        if parent:parent.node.appendChild(self.node)
        self.configure(**kw)
    def configure(self,**kw):
        for k,v in kw.items():
            if k=='text':self.node.textContent=str(v)
            elif k=='bg':self.node.style.backgroundColor=color(v)
            elif k=='fg':self.node.style.color=color(v)
    config=configure
    def grid(self,column=0,row=0,**kw):
        self.parent.node.classList.add('cell-grid');self.node.style.gridColumn=str(column+1);self.node.style.gridRow=str(row+1);self.node.setAttribute('aria-label',f'Cell {column+1}, {row+1}')
    def place(self,**kw):pass
    def bind(self,event,handler):
        kind='contextmenu' if event=='<Button-3>' else 'click'
        def invoke(e):
            e.preventDefault()
            try:handler(e)
            except SystemExit:pass
        proxy=create_proxy(invoke);_callbacks.append(proxy);self.bindings[event]=(kind,proxy);self.node.addEventListener(kind,proxy)
    def unbind(self,event):
        if event in self.bindings:
            kind,proxy=self.bindings.pop(event);self.node.removeEventListener(kind,proxy)
class Tk(Widget):
    def __init__(self):
        self.node=document.getElementById('python-game');self.node.replaceChildren();self.bindings={}
    def geometry(self,*a):pass
    def title(self,*a):pass
    def resizable(self,*a):pass
    def mainloop(self):pass
class Frame(Widget):pass
class Label(Widget):pass
class Button(Widget):
    tag='button'

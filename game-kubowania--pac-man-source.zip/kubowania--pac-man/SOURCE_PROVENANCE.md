# Imported tutorial source

Repository: https://github.com/kubowania/pac-man
Commit: bfb16e282aed06c033b16d7e74caf152c880dbcd

Matched public author repository and project subject; exact tutorial endpoint unverified:
- 1 hour Pac-man in JavaScript! — https://www.youtube.com/watch?v=q2ViNbRwr5U

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

# Tutorial provenance

Playlist: Simulations
Position: 14
Title: Multi-room Platformer Game Tutorial with JavaScript and HTML Canvas
Video: https://www.youtube.com/watch?v=Lcdc2v-9PjA
Author repository: https://github.com/chriscourses/kings-and-pigs
Pinned commit: bb77e92e7d89937500138ef690388fe067c2a4b1

Repository link verified in the exact video's description. Original code and attribution retained. This is an imported tutorial project, not a claim of original authorship.

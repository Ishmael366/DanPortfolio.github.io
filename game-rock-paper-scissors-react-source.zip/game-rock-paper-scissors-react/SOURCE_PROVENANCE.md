# Imported tutorial source

Repository: https://github.com/kubowania/rock-paper-scissors-react
Commit: 0f61abab6bd39c349121ee6105ab6dd2a4a08174

Matched public author repository and project subject; exact tutorial endpoint unverified:
- Rock Paper Scissors in React vs JavaScript — https://www.youtube.com/watch?v=TIefmKAWMTo

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

# Source provenance

Playlist: Simulations / position 15
Tutorial: HTML5 Canvas and JavaScript Game Tutorial
Video: https://www.youtube.com/watch?v=eI9idPTT0c4
Author repository: https://github.com/chriscourses/HTML5-Canvas-and-JavaScript-Games-for-Beginners
Commit: 5e1b6f29c170092f4b274133a6bd75afca682cae

Matched by tutorial author and game subject. The video description does not link this repository directly; exact lesson endpoint is not confirmed. Preserve upstream credit.

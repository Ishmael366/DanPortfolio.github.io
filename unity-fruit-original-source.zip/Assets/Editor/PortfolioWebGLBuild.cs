using System;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
public static class PortfolioWebGLBuild {
public static void Run() {
try {
var args = System.Environment.GetCommandLineArgs();
var output = args[System.Array.IndexOf(args, "-portfolioOutput") + 1];
var scenes = System.IO.File.ReadAllLines("portfolio-scenes.txt").Where(p => !String.IsNullOrWhiteSpace(p)).ToArray();
PlayerSettings.runInBackground = true;
PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Disabled;
PlayerSettings.WebGL.dataCaching = true;
PlayerSettings.WebGL.exceptionSupport = WebGLExceptionSupport.ExplicitlyThrownExceptionsOnly;
PlayerSettings.defaultWebScreenWidth = 1280;
PlayerSettings.defaultWebScreenHeight = 720;
foreach(var prefab in new[]{"Assets/Prefab/Watermelon.prefab","Assets/Prefab/Watermelon_Sliced.prefab"}) {
 var obj=PrefabUtility.LoadPrefabContents(prefab);
 string model=prefab.Contains("Sliced")?"Assets/Models/Watermelon_Sliced.fbx":"Assets/Models/Watermelon.fbx";
 var meshes=AssetDatabase.LoadAllAssetsAtPath(model).OfType<Mesh>().ToArray();
 if(meshes.Length==0)throw new Exception("Missing original fruit mesh: "+model);
 foreach(var mf in obj.GetComponentsInChildren<MeshFilter>(true)) {
  var match=meshes.FirstOrDefault(m=>m.name.Replace(".","_")==mf.name.Replace(".","_"));
  var original=match??meshes[0];
  Debug.Log("FRUIT_AUTHORED_BOUNDS "+original.name+" "+original.bounds.size);
  var full=AssetDatabase.LoadAllAssetsAtPath("Assets/Models/Watermelon.fbx").OfType<Mesh>().First();
  float unitScale=1f/Mathf.Max(full.bounds.size.x,Mathf.Max(full.bounds.size.y,full.bounds.size.z));
  var mesh=UnityEngine.Object.Instantiate(original);mesh.name=original.name+"BrowserUnits";
  mesh.vertices=mesh.vertices.Select(v=>v*unitScale).ToArray();mesh.RecalculateBounds();
  string path="Assets/Models/"+System.IO.Path.GetFileNameWithoutExtension(prefab)+"-"+mf.name+"-browser.asset";
  AssetDatabase.DeleteAsset(path);AssetDatabase.CreateAsset(mesh,path);mf.sharedMesh=mesh;
 }
 PrefabUtility.SaveAsPrefabAsset(obj,prefab);PrefabUtility.UnloadPrefabContents(obj);
}
var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions { scenes = scenes, locationPathName = output, target = BuildTarget.WebGL, options = BuildOptions.None });
Debug.Log("PORTFOLIO_BUILD_RESULT " + report.summary.result + " " + report.summary.totalSize);
EditorApplication.Exit(report.summary.result == BuildResult.Succeeded ? 0 : 1);
} catch (Exception e) { Debug.LogException(e); EditorApplication.Exit(1); }
}
}

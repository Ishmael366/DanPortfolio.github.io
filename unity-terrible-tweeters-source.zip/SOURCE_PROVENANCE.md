Upstream: https://github.com/bslease/Terrible-Tweeters
Commit: a32b2b343524e6bcc92a97bbc3a6a4ae24842cb1
Tutorial video ID: Lu76c85LhGY
Original source and notices retained. Browser verification and publication tracked separately.

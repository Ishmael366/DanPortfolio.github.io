using System;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEditor;
using UnityEditor.SceneManagement;
public static class PortfolioSceneAudit {
 [Serializable] public class Item {public string name;public bool active;public bool interactable;public string[] methods;public string[] targets;}
 [Serializable] public class Report {public Item[] buttons; public string[] raycasters;public string[] scripts;public string[] waveInfo;}
 public static void Run(){try{EditorSceneManager.OpenScene("Assets/Level01.unity");var buttons=UnityEngine.Object.FindObjectsOfType<Button>(true).Select(b=>new Item{name=b.name,active=b.gameObject.activeInHierarchy,interactable=b.interactable,methods=Enumerable.Range(0,b.onClick.GetPersistentEventCount()).Select(i=>b.onClick.GetPersistentMethodName(i)).ToArray(),targets=Enumerable.Range(0,b.onClick.GetPersistentEventCount()).Select(i=>b.onClick.GetPersistentTarget(i)?b.onClick.GetPersistentTarget(i).name:"MISSING").ToArray()}).ToArray();var report=new Report{buttons=buttons,raycasters=UnityEngine.Object.FindObjectsOfType<GraphicRaycaster>(true).Select(c=>c.name+" active="+c.enabled+" reversed="+c.ignoreReversedGraphics).ToArray(),scripts=UnityEngine.Object.FindObjectsOfType<MonoBehaviour>(true).Where(c=>c!=null).Select(c=>c.name+" "+c.GetType().Name+" active="+c.isActiveAndEnabled).ToArray(),waveInfo=UnityEngine.Object.FindObjectsOfType<WaveSpawner>(true).Select(w=>"Waves "+w.waves.Length+" active="+w.isActiveAndEnabled).ToArray()};System.IO.File.WriteAllText("portfolio-scene-audit.json",JsonUtility.ToJson(report,true));EditorApplication.Exit(0);}catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}

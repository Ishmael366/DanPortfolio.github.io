# Tutorial provenance

Playlist: Simulations
Position: 4
Title: Create a Donkey Kong Country-ish Platformer in JavaScript
Video: https://www.youtube.com/watch?v=431MtYtTmgs
Author repository: https://github.com/chriscourses/sunnyland-platformer
Pinned commit: 99d9f5e622228cc47c8dd8b9751689de0629bc19

Repository link verified in the exact video's description. Original code and attribution retained. This is an imported tutorial project, not a claim of original authorship.

# Imported tutorial source

Repository: https://github.com/kubowania/Tetris-Basic
Commit: a5b4d2bb17ca01234f23803c8fe86ee893b4bd45

Linked directly in these playlist video descriptions:
- Code Tetris: JavaScript Tutorial for Beginners — https://www.youtube.com/watch?v=rAUn1Lom6dw

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

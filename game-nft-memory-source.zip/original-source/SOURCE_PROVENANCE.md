# Imported tutorial source

Repository: https://github.com/dappuniversity/blockchain_game
Commit: a5479871664c197f541147028526d53ba4c8521c

Linked directly in these playlist video descriptions:
- Build a Blockchain NFT Memory Matching Game - Dapp University — https://www.youtube.com/watch?v=x-6ruqmNS3o

Original authorship and upstream license files are retained. Import only; build/run completion is not implied. Git LFS payloads are not automatically downloaded.

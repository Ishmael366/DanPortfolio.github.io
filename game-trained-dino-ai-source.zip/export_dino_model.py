from pathlib import Path
import io,zipfile,torch
from torch import nn
class DinoQ(nn.Module):
 def __init__(self,s):
  super().__init__();self.cnn=nn.Sequential(nn.Conv2d(1,32,8,4),nn.ReLU(),nn.Conv2d(32,64,4,2),nn.ReLU(),nn.Conv2d(64,64,3,1),nn.ReLU(),nn.Flatten());self.linear=nn.Sequential(nn.Linear(3456,512),nn.ReLU());self.output=nn.Linear(512,3)
  for i in [0,2,4]:self.cnn[i].weight.data.copy_(s[f'q_net.features_extractor.cnn.{i}.weight']);self.cnn[i].bias.data.copy_(s[f'q_net.features_extractor.cnn.{i}.bias'])
  self.linear[0].weight.data.copy_(s['q_net.features_extractor.linear.0.weight']);self.linear[0].bias.data.copy_(s['q_net.features_extractor.linear.0.bias']);self.output.weight.data.copy_(s['q_net.q_net.0.weight']);self.output.bias.data.copy_(s['q_net.q_net.0.bias'])
 def forward(self,x):return self.output(self.linear(self.cnn(x/255.0)))
p=Path('work/remaining-browser-originals')
with zipfile.ZipFile('work/dino-model/best_model_88000.zip') as z:s=torch.load(io.BytesIO(z.read('policy.pth')),weights_only=True,map_location='cpu')
m=DinoQ(s).eval();x=torch.zeros((1,1,83,100),dtype=torch.float32);torch.onnx.export(m,x,str(p/'dino-trained-q.onnx'),input_names=['observation'],output_names=['q_values'],opset_version=17,dynamo=False);print('Exported trained model', (p/'dino-trained-q.onnx').stat().st_size, 'bytes; sample output',m(x).detach().numpy().tolist())
